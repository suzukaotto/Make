#include <iostream>
#include <conio.h>
using namespace std;

enum {k1=49, k2, k3};

int main(){
	while(1) {
		system("cls");
		cout<<"firewall blocker"          <<endl;
		cout<<"press key the number"      <<endl;
		cout<<"------------------------"  <<endl;
		cout<<"1. block the firewall"     <<endl;
		cout<<"2. unblock the firewall"   <<endl;
		cout<<"3. program Exit"           <<endl;
		cout<<"------------------------"  <<endl;
		cout<<">> ";
		
		switch(getch()) {
			case k1:
				cout<<"1"<<endl<<endl;
				cout<<"block the firewall"<<endl<<endl;
				
				system("\"bin\\block_the_firewall.bat\"");
				cout<<endl<<endl<<"success";
				break;
				
			case k2:
				cout<<"2"<<endl<<endl;
				cout<<"unblock the firewall"<<endl<<endl;
				
				system("\"bin\\unblock_the_firewall.bat\"");
				cout<<endl<<endl<<"success";
				break;
				
			case k3:
				cout<<"3"<<endl<<endl;
				cout<<"Exit by pressing any key . . . ";
				getch();
				return 0;
			
			case 3: //Ctrl + C
				return 0;
			
			default:
				cout<<"X"<<endl<<endl;
				cout<<"invalid number. Please retype.";
		}
		
		cout<<endl<<endl<<"return menu . . . ";
		getch();
	}
}
